<?php
	session_start();

	include('includes/dbcon.php');
	
	$target_dir = "images/" . time();
	$target_file = $target_dir . basename($_FILES['image']["name"]);

	if (move_uploaded_file($_FILES['image']["tmp_name"], $target_file)) {

		$id = $_SESSION['id'];

        $mysqli->query("UPDATE users SET avatar='$target_file' WHERE user_id='$id'");
        $_SESSION['successMSG'] = "Avatar Successfully Updated !";
    } else {
        $_SESSION['errorMSG'] = "There was a problem uploading your image. Please try again !";
    }
	
	header("Location: profile.php");
?>