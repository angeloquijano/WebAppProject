<?php
	session_start();

	include('includes/dbcon.php');
	
	$target_dir = "images/";
	$target_file = $target_dir . basename($_FILES['image']["name"]);

	if (move_uploaded_file($_FILES['image']["tmp_name"], $target_file)) {

		$id = $_SESSION['id'];
		$postId = $_POST['id'];
		$caption = $_POST['caption'];

        $mysqli->query("UPDATE posts SET caption='$caption', img='$target_file' WHERE id='$postId'");
        $_SESSION['successMSG'] = "Successfully Updated !";
    } else {
        $_SESSION['errorMSG'] = "There was a problem updating your image. Please try again !";
    }
	
	header("Location: home.php");
?>