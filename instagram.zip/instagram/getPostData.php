<?php
    include('includes/dbcon.php');

    $id = $_POST['id'];

    echo json_encode($mysqli->query("SELECT * FROM POSTS WHERE id = '$id'")->fetch_assoc());
?>