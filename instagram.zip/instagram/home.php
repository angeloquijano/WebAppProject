<?php include('includes/mainHeader.php'); ?>

<!--main-->
<div class="container" id="main">
   <div class="row">

      <div class="col-sm-6 col-md-4 col-2">
      </div>

      <div class="col-sm-6 col-md-4 col-1">
      </div>

      <div class="col-sm-6 col-md-4 col-3">
      </div>
  </div>
  
  	<hr>
    
    <br>
    
    <div class="clearfix"></div>
      
    <!-- <hr>
    <div class="col-md-12 text-center"><p><a href="http://usebootstrap.com/theme/google-plus" target="_ext">Download Google Plus Style Template</a><br><a href="http://usebootstrap.com/theme/google-plus" target="_ext">More Bootstrap Templates by @Bootply</a></p></div>
    <hr> -->
    
  </div>
</div><!--/main-->

<!-- POST BUTTON -->
<a class="btn btn-info create-post" title="Create Post" data-toggle="tooltip" style="position: fixed; right: 3%; bottom: 5%; border-radius: 20px; padding-left: 10px; padding-right: 10px;">
  <i class="fa fa-plus"></i>
</a>

<?php include('includes/mainFooter.php'); ?>

<?php

  include('includes/dbcon.php');
  $id = $_SESSION['id'];

  $sql = "SELECT * FROM posts INNER JOIN users ON posts.user_id = users.user_id WHERE users.privacy='public' OR users.user_id = '$id'";
  $result = $mysqli->query($sql);

  $ctr = 1;

  if ($result->num_rows > 0) {
    while($post = $result->fetch_assoc()) {

      $id = $post['user_id'];
      $sql = "SELECT CONCAT(fname, ' ', lname) as name, user_id as id, avatar FROM users where user_id = '$id'";
      $user = $mysqli->query($sql)->fetch_assoc();
      $name = $user['name'];

      ?>
        <script type="text/javascript">
          $('.col-<?php echo $ctr; ?>').append(`
            <div class="panel panel-default" id="post-` + <?php echo $post['id'] ?> + `">
              <div class="panel-heading">

                <?php if($_SESSION['id'] == $id) {?>
                <!-- POST OPTIONS -->
                <a href="#" class="dropdown-toggle pull-right" data-toggle="dropdown">
                  <small><i class="fa fa-ellipsis-h"></i></small>
                </a>
                <ul class="nav dropdown-menu pull-right" style="position: absolute; top: 35px; right: 30px">
                  <li class="edit-post" data-id="<?php echo $post['id'] ?>"><a><i class="fa fa-pencil"></i> Edit</a></li>
                  <li class="delete-post" data-id="<?php echo $post['id'] ?>"><a><i class="fa fa-cross"></i> Delete</a></li>
                </ul>
                <?php } ?>
                 
                 <a href="timeline.php?user_id=<?php echo $user['id']; ?>" class="timeline-link">
                 <h4>
                   <img src="<?php echo $user['avatar'] ?>" alt="user_avatar" width="25px" height="25px">
                   <?php echo $name; ?>
                 </h4>
                 </a>

               </div>
              <div class="panel-thumbnail"><img src="<?php echo $post['img'] ?>" class="img-responsive"></div>
              <div class="panel-body">
               <h4></h4>
                <p class="lead"><?php echo $post['caption'] ?></p>
                <p>6 Likes, 9 Comments</p>
                
                <p>
                  <img src="assets/img/uFp_tsTJboUY7kue5XAsGAs28.png" height="28px" width="28px">
                  <img src="assets/img/photo_002.jpg" height="28px" width="28px">
                </p>
              </div>
            </div>`);
        </script>
      <?php
      $ctr++;
      if($ctr == 4)
      {
        $ctr = 1;
      }
    }
  }
  else
  {
    ?>
      <script>
        $('.col-1').append(`<div class='alert alert-info dismissable'>You have no posts and probably no other account is on public account.</div>`);
        $('hr').remove();
      </script>
    <?php
  }
?>

<script>

  <?php
    if(isset($_SESSION['errorMSG']))
    {
  ?>
      swal({
        title: '<?php echo $_SESSION['errorMSG']?>',
        type: 'error',
        showConfirmButton: false,
        timer: 2000
      });
  <?php
      unset($_SESSION['errorMSG']);
    }
    else if(isset($_SESSION['successMSG']))
    {
  ?>
      swal({
        title: '<?php echo $_SESSION['successMSG']?>',
        type: 'success',
        showConfirmButton: false,
        timer: 2000
      });
  <?php
      unset($_SESSION['successMSG']);
    }
  ?>

  $('.create-post').on('click', () => {
    swal({
      showCancelButton: true,
      confirmButtonText: 'POST',
      allowOutsideClick: false,
      onOpen: () => {
        $('#swal2-content label').css({
          'text-align': 'left',
          'display': 'block',
        });
        $('label h4').css({
          'border-bottom-width': '0px',
          'padding-bottom': '0px',
        });
        $('#preview, [type="file"]').css('margin-bottom', '10px');

        $('#image').on('change', () => {
          type = $('#image').val().split('.').pop();

          if(!['jpg', 'png', 'gif'].includes(type.toLowerCase()))
          {
            swal.showValidationError(
              'Pick only a valid image format. (PNG, JPG, GIF)'
            );

            if($('#preview').is(':visible'))
            {
              $('#preview').fadeOut();
            }

            $('#image').val('');

          }
          else
          {
            if(!$('#preview').is(':visible'))
            {
              $('#preview').fadeIn();
            }

            if($('.swal2-validationerror').is(':visible'))
            {
              $('.swal2-validationerror').fadeOut();
            }

            var fr = new FileReader();
            fr.readAsDataURL(document.getElementById("image").files[0]);

            fr.onload = function (e) {
                document.getElementById("preview").src = e.target.result;
            };
          }
        });
      },
      html: `
        <form action="post.php" method="POST" id="postForm" enctype="multipart/form-data">
          <label><h4><b>Caption</b><br></h4></label>
          <textarea id="caption" name="caption" cols="30" rows="3" class="form-control" placeholder="Enter Caption"></textarea>
          <label><h4><b>Image</b><br></h4></label>
          <input type="file" name="image" id="image" class="form-control"/>
          <img src="" id="preview" width="100%" height="100%" style="display: none;"/>
        </form>
      `,
    }).then((result) => {
      if(result.value)
      {
        $('#postForm').submit();
      }
    })
  });

  $('.edit-post').on('click', e => {
    $.ajax({
      url: 'getPostData.php',
      data: {id: $(e.currentTarget).attr('data-id')},
      type: 'POST',
      success: result => {
        result = JSON.parse(result);
        
        swal({
          showCancelButton: true,
          confirmButtonText: 'UPDATE',
          allowOutsideClick: false,
          onOpen: () => {
            $('#swal2-content label').css({
              'text-align': 'left',
              'display': 'block',
            });
            $('label h4').css({
              'border-bottom-width': '0px',
              'padding-bottom': '0px',
            });
            $('#preview, [type="file"]').css('margin-bottom', '10px');

            $('#image').on('change', () => {
              type = $('#image').val().split('.').pop();

              if(!['jpg', 'png', 'gif'].includes(type.toLowerCase()))
              {
                swal.showValidationError(
                  'Pick only a valid image format. (PNG, JPG, GIF)'
                );

                if($('#preview').is(':visible'))
                {
                  $('#preview').fadeOut();
                }

                $('#image').val('');

              }
              else
              {
                if(!$('#preview').is(':visible'))
                {
                  $('#preview').fadeIn();
                }

                if($('.swal2-validationerror').is(':visible'))
                {
                  $('.swal2-validationerror').fadeOut();
                }

                var fr = new FileReader();
                fr.readAsDataURL(document.getElementById("image").files[0]);

                fr.onload = function (e) {
                    document.getElementById("preview").src = e.target.result;
                };
              }
            });
          },
          html: `
            <form action="updatePost.php" method="POST" id="postForm" enctype="multipart/form-data">
              <label><h4><b>Caption</b><br></h4></label>
              <input type="hidden" name="id" value="` + result.id  + `" />
              <textarea id="caption" name="caption" cols="30" rows="3" class="form-control" placeholder="Enter Caption">` + result.caption + `</textarea>
              <label><h4><b>Image</b><br></h4></label>
              <input type="file" name="image" id="image" class="form-control" placeholder="Post New Image"/>
              <img src=" ` + result.img + `" id="preview" width="100%" height="100%"/>
            </form>
          `,
        }).then((result) => {
          if(result.value)
          {
            $('#postForm').submit();
          }
        })
      }
    })
  });

  $('.delete-post').on('click', e => {
    id = $(e.currentTarget).attr('data-id');

    swal({
      title: 'Are you sure you want to delete this post',
      type: 'question',
      showCancelButton: true,
    }).then(result => {
      if(result.value){
        $.ajax({
          url: 'deletePost.php',
          data: {id, id},
          type: 'POST',
          success: result => {
            if(result)
            {
              swal({
                title: 'Your post has been successfully deleted',
                type: 'success',
                showConfirmButton: false,
                timer: 800
              }).then(() => {
                $('#post-' + id).fadeOut();
              })
            }
            else
            {
              swal({
                title: 'There was a problem deleting your post',
                type: 'error',
                showConfirmButton: false,
                timer: 800
              })
            }
          }
        })
      }
    });
  });
</script>

</body></html>