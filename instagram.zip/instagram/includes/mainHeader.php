<?php
  session_start();
  if(!isset($_SESSION['id']))
  {
    $_SESSION['errorMSG'] = "You must log in first !";

    header("Location: index.php");
  }
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <meta http-equiv="content-type" content="text/html; charset=UTF-8"> 
  <meta charset="utf-8">

  <title>Instagram</title>

  <link href="assets/css/bootstrap.css" rel="stylesheet">      
  <link href="assets/css/google-plus.css" rel="stylesheet">
  <link href="css/fontawesome-all.min.css" rel="stylesheet">
  <link href="css/swal.css" rel="stylesheet">
  <link href="css/main.css" rel="stylesheet">
</head>
    
<body class="">
        
  <div class="navbar navbar-fixed-top header">
 	  <div class="col-md-12">
      <div class="navbar-header">  
        <a href="index.php" class="navbar-brand">Instagram</a>

        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse1">
          <i class="glyphicon glyphicon-search"></i>
        </button>
      </div>
      
      <div class="collapse navbar-collapse" id="navbar-collapse1">
          <form class="navbar-form pull-left">
              <div class="input-group" style="max-width:470px;">
                <input class="form-control" placeholder="Search" name="srch-term" id="srch-term" type="text">
                <div class="input-group-btn">
                  <button class="btn btn-default btn-primary" type="submit"><i class="fa fa-search"></i></button>
                </div>
              </div>
          </form>
          <ul class="nav navbar-nav navbar-right">
             <li class="">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-bell"></i></a>
                <ul class="dropdown-menu">
                  <li><a href="#"><span class="badge pull-right">40</span>Link</a></li>
                  <li><a href="#"><span class="badge pull-right">2</span>Link</a></li>
                  <li><a href="#"><span class="badge pull-right">0</span>Link</a></li>
                  <li><a href="#"><span class="label label-info pull-right">1</span>Link</a></li>
                  <li><a href="#"><span class="badge pull-right">13</span>Link</a></li>
                </ul>
             </li>
             <li><a href="profile.php"><i class="fa fa-user">
               <?php
                echo $_SESSION['fname'] . ' ' . $_SESSION['lname'];
               ?>
             </i></a></li>
           </ul>
        </div>	
     </div>	
</div>
<div class="navbar navbar-default" id="subnav">
    <div class="col-md-12">
        <div class="navbar-header">
          
          <a href="#" style="margin-left:15px;" class="navbar-btn btn btn-default btn-plus dropdown-toggle" data-toggle="dropdown"><i class="fa fa-home" style="color:#dd1111;"></i> Home <small><i class="fa fa-chevron-down"></i></small></a>
          <ul class="nav dropdown-menu">
              <li><a href="profile.php"><i class="fa fa-user" style="color:#1111dd;"></i> Profile</a></li>
              <li><a href="index.php"><i class="fa fa-tachometer-alt" style="color:#0000aa;"></i> News Feed</a></li>
              <!-- <li><a href="#"><i class="fa fa-inbox" style="color:#11dd11;"></i> Pages</a></li> -->
              <li class="nav-divider"></li>
              <!-- <li><a href="#"><i class="fa fa-cog" style="color:#dd1111;"></i> Settings</a></li> -->
              <li><a href="logout.php"><i class="fa fa-sign-out-alt" style="color:#dd1111;"></i> Logout</a></li>
          </ul>
          
          
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse2">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
      
        </div>
     </div>	
</div>