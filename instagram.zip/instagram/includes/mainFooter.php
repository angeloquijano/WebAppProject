<script type="text/javascript" src="assets/js/jquery.js"></script>
  <script type="text/javascript" src="assets/js/bootstrap.js"></script>
  <script type="text/javascript" src="js/swal.js"></script>

  <script type="text/javascript">
  
  $(document).ready(function() {
  
  });
  
  </script>
    