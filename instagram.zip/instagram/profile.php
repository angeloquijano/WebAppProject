<?php include('includes/mainHeader.php'); ?>

<?php
    include('includes/dbcon.php');

    if(isset($_POST['submit'])){

        $id = $_SESSION['id'];
        $fname = $_POST['fname'];
        $lname = $_POST['lname'];
        $mname = $_POST['mname'];
        $uname = $_POST['uname'];
        $email = $_POST['email']; 

        $err = 0;

        if(empty($fname)){
            $err =  1;
            $fnameErr = "First Name is required";
        }
        elseif(!preg_match("/^[a-zA-Z -]+$/", $fname)) {
            $err =  1;
            $fnameErr = "First Name must be letters only";
        }
        if(empty($mname)){
            $err =  1;
            $mnameErr = "Middle Name is required";
        }
        elseif(!preg_match("/^[a-zA-Z -]+$/", $mname)) {
            $err =  1;
            $mnameErr = "Middle Name must be letters only";
        }
        if(empty($lname)){
            $err =  1;
            $lnameErr = "Last Name is required";
        }
        elseif(!preg_match("/^[a-zA-Z -]+$/", $lname)) {
            $err =  1;
            $lnameErr = "Last Name must be letters only";
        }
        if(empty($uname)){
            $err =  1;
            $unameErr = "Username is required";
        }
        elseif(strlen($uname) < 5){
            $err =  1;
            $unameErr = "Username must be minimum of 5 letters";
        }
        if(empty($email)){
            $err =  1;
            $emailErr = "Email is required";
        }
        elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
          $emailErr = "Invalid email format"; 
        }

        if($err == 0){

            $SQL = $mysqli->query("UPDATE users SET fname = '$fname', mname = '$mname', lname = '$lname', username = '$uname', email = '$email' WHERE user_id = '$id'");

            $_SESSION['fname'] = $fname;
            $_SESSION['mnane'] = $mname;
            $_SESSION['lname'] = $lname;
            $_SESSION['username'] = $uname;
            $_SESSION['email'] = $email;
            
            $_SESSION['successMSG'] = "Profile successfully updated.";

            header("Location: profile.php");
        }
    }
    elseif(isset($_POST['changePass'])){

        $id = $_SESSION['id'];
        $old_password = $_POST['old_password'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];

        $sql = "SELECT password FROM users where user_id = '$id'";
        $user = $mysqli->query($sql)->fetch_assoc();
        $password = $user['password'];

        if($old_password != $password)
        {
            $_SESSION['errorMSG'] = 'Old password does not match';
        }
        elseif($new_password != $confirm_password)
        {
            $_SESSION['errorMSG'] = 'Confirm password does not match';
        }
        else
        {
            $mysqli->query("UPDATE users SET password='$new_password' WHERE user_id='$id'");
            $_SESSION['successMSG'] = 'Successfully updated password';
        }
    }
?>

<div class="container" id="main">
    
    <div class="row">
        <div class="col-md-3"> 
            <div class="panel panel-default">
                <?php 
                    $id = $_SESSION['id'];
                    $sql = "SELECT avatar, privacy FROM users where user_id = '$id'";
                    $user = $mysqli->query($sql)->fetch_assoc();
                ?>

                <div class="panel-heading">
                    <h4>AVATAR</h4>
                </div>

                <div class="panel-body" style="padding-top: 0px">
                    <img src="<?php echo $user['avatar'] ?>" width="100%" style="max-height: 200px;"/>
                    
                    <br>
                    <br>

                    <a class="btn btn-info change-profile">UPLOAD NEW AVATAR</a>
                </div>

            </div>

            <div class="panel panel-default">

                <div class="panel-body">
                    <div class="row" style="text-align: center;">

                        <div class="col-sm-7" style="font-size: 16px;">
                            <label>Private Account</label>
                        </div>

                        <div class="col-sm-5">
                            <label class="switch">
                                <input type="checkbox" id="privacy">
                                <span class="slider round"></span>
                            </label>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <div class="col-md-6">
            <div class="panel panel-default">

                <ul id="tabs" class="nav nav-tabs" data-tabs="tabs">
                    <li role="presentation" class="active"><a href="#account-details" data-toggle="tab">Account Details</a></li>
                    <li role="presentation"><a href="#password" data-toggle="tab">Password</a></li>
                </ul>

                <div id="my-tab-content" class="tab-content">
                    <div class="tab-pane active" id="account-details">
                        <div class="panel-body" style="padding-top: 0px">
                            <h4>
                                <?php
                                    if(isset($_SESSION['errorMSG'])){
                                        echo "<div class='alert alert-danger dismissable'>".$_SESSION['errorMSG']."</div>";
                                        unset($_SESSION['errorMSG']);
                                    }
                                    elseif(isset($_SESSION['successMSG'])){
                                        echo "<div class='alert alert-success dismissable'>".$_SESSION['successMSG']."</div>";
                                        unset($_SESSION['successMSG']);
                                    }
                                ?>

                                    <form method="POST" action="profile.php">
                                        <input type="hidden" name="id" value="<?= $_SESSION['id'] ?>">

                                        <div class="form-group">
                                            <label>First Name</label>
                                            <input type="text" name="fname" value="<?= $_SESSION['fname'] ?>" class="form-control" placeholder="First Name">
                                            <?php
                                                if(isset($fnameErr)){
                                                    echo "<div class='alert alert-danger'>$fnameErr</div>";
                                                }
                                            ?>
                                        </div>

                                        <div class="form-group">
                                            <label>Middle Name</label>
                                            <input type="text" name="mname" value="<?= $_SESSION['mname'] ?>" class="form-control" placeholder="Middle Name">
                                            <?php
                                                if(isset($mnameErr)){
                                                    echo "<div class='alert alert-danger'>$mnameErr</div>";
                                                }
                                            ?>
                                        </div>

                                        <div class="form-group">
                                            <label>Last Name</label>
                                            <input type="text" name="lname" value="<?= $_SESSION['lname'] ?>" class="form-control" placeholder="Last Name">
                                            <?php
                                                if(isset($lnameErr)){
                                                    echo "<div class='alert alert-danger'>$lnameErr</div>";
                                                }
                                            ?>
                                        </div>

                                        <div class="form-group">
                                            <label>Username</label>
                                            <input type="text" name="uname" value="<?= $_SESSION['username'] ?>" class="form-control" placeholder="Username">
                                            <?php
                                                if(isset($unameErr)){
                                                    echo "<div class='alert alert-danger'>$unameErr</div>";
                                                }
                                            ?>
                                        </div>

                                        <div class="form-group">
                                            <label>Email address</label>
                                            <input type="text" name="email" value="<?= $_SESSION['email'] ?>" class="form-control" placeholder="Email">
                                            <?php
                                                if(isset($emailErr)){
                                                    echo "<div class='alert alert-danger'>$emailErr</div>";
                                                }
                                            ?>
                                        </div>

                                        <input type="submit" name="submit" class="btn btn-success" value="REGISTER">
                                    </form>
                            </h4>
                        </div>
                    </div>
                    <div class="tab-pane" id="password">
                        <div class="panel-body" style="padding-top: 0px">
                            <h4>
                                <?php
                                    if(isset($_SESSION['errorMSG'])){
                                        echo "<div class='alert alert-danger dismissable'>".$_SESSION['errorMSG']."</div>";
                                        unset($_SESSION['errorMSG']);
                                    }
                                    elseif(isset($_SESSION['successMSG'])){
                                        echo "<div class='alert alert-success dismissable'>".$_SESSION['successMSG']."</div>";
                                        unset($_SESSION['successMSG']);
                                    }
                                ?>

                                    <form method="POST" action="profile.php">
                                        <input type="hidden" name="id" value="<?= $_SESSION['id'] ?>">

                                        <div class="form-group">
                                            <label>Old Password</label>
                                            <input type="password" name="old_password" class="form-control" placeholder="Old Password" required>
                                        </div>

                                        <div class="form-group">
                                            <label>New Password</label>
                                            <input type="password" name="new_password" class="form-control" placeholder="New Password" required>
                                        </div>

                                        <div class="form-group">
                                            <label>Confirm Password</label>
                                            <input type="password" name="confirm_password" class="form-control" placeholder="Confirm Password" required>
                                        </div>

                                        <input type="submit" name="changePass" class="btn btn-success" value="CONFIRM">
                                    </form>
                            </h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3"> </div>
    </div>
    
    <div class="clearfix"></div>
</div><!--/main-->

<?php include('includes/mainFooter.php'); ?>

<script>

    $(document).ready(() => {
        $('#tabs').tab();

        <?php if($user['privacy'] == 'private') {?>
        $('#privacy').click();
        <?php } ?>
    });

    $('.slider').on('click', () => {
        if($('.slider').css('background-color') == "rgb(204, 204, 204)")
        {
            privacy = 'private';
        }
        else
        {
            privacy = 'public';
        }

        swal({
            title: 'Are you sure ?',
            showCancelButton: true,
        }).then((result) => {
            if(result.dismiss)
            {
                $('#privacy').click();
            }
            else if(result.value)
            {
                privacy = $('.slider').css('background-color') == "rgb(33, 150, 243)" ? 'private' : 'public';
                
                $.ajax({
                    url: 'updatePrivacy.php',
                    method: 'POST',
                    data: {
                        id: <?php echo $_SESSION['id']; ?>,
                        privacy: privacy
                    },
                    success: result => {
                        if(result)
                        {
                            swal({
                                title: 'Successfully updated privacy settings',
                                type: 'success',
                                showConfirmButton: false,
                                timer: 800
                            });
                        }
                        else
                        {
                            swal({
                                title: 'There was a problem updating your privacy settings',
                                type: 'error',
                                showConfirmButton: false,
                                timer: 800
                            }).then(() => {
                                $('#privacy').click();
                            })
                        }
                    }
                })
            }
        });
    });

    $('.change-profile').on('click', () => {
      swal({
        showCancelButton: true,
        confirmButtonText: 'UPDATE',
        allowOutsideClick: false,
        onOpen: () => {
          $('#swal2-content label').css({
            'text-align': 'left',
            'display': 'block',
          });
          $('label h4').css({
            'border-bottom-width': '0px',
            'padding-bottom': '0px',
          });
          $('#preview, [type="file"]').css('margin-bottom', '10px');

          $('#image').on('change', () => {
            type = $('#image').val().split('.').pop();

            if(!['jpg', 'png', 'gif'].includes(type.toLowerCase()))
            {
              swal.showValidationError(
                'Pick only a valid image format. (PNG, JPG, GIF)'
              );

              if($('#preview').is(':visible'))
              {
                $('#preview').fadeOut();
              }

              $('#image').val('');

            }
            else
            {
              if(!$('#preview').is(':visible'))
              {
                $('#preview').fadeIn();
              }

              if($('.swal2-validationerror').is(':visible'))
              {
                $('.swal2-validationerror').fadeOut();
              }

              var fr = new FileReader();
              fr.readAsDataURL(document.getElementById("image").files[0]);

              fr.onload = function (e) {
                  document.getElementById("preview").src = e.target.result;
              };
            }
          });
        },
        html: `
          <form action="changeProfile.php" method="POST" id="postForm" enctype="multipart/form-data">
            <label><h4><b>Image</b><br></h4></label>
            <input type="file" name="image" id="image" class="form-control"/>
            <img src="" id="preview" width="100%" height="100%" style="display: none;"/>
          </form>
        `,
      }).then((result) => {
        if(result.value)
        {
          $('#postForm').submit();
        }
      })
    });
</script>

</body></html>