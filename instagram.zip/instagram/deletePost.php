<?php
    include('includes/dbcon.php');

    $id = $_POST['id'];

    echo $mysqli->query("DELETE FROM posts WHERE id='$id'");
?>