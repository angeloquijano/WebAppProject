<?php include('includes/header.php'); ?>
<?php include('includes/navbar.php'); ?>

<?php 
    //Check session, if not registered, redirect to index.php
    // session_start();
    if(!isset($_SESSION['id'])){
        header("Location: notLoggedIn.php");
    }
    unset($_SESSION['errorMSG']);
?>


<div class="row">
    <div class="col-md-3"> </div>
    <div class="col-md-6"> 

    <?php
        if(isset($_SESSION['successMSG'])){
            echo "<div class='alert alert-success dismissable'>".$_SESSION['successMSG']."</div>";
            unset($_SESSION['successMSG']);
        }
    ?>
    
    <h1>
            <b>ACCOUNT DETAILS:</b> <br>
    </h1>
    <h3>
            ID:         <?= $_SESSION['id'] ?><br>
            USERNAME: <?= $_SESSION['username'] ?><br>
            EMAIL:  <?= $_SESSION['email'] ?><br>
            FIRST NAME:   <?= $_SESSION['fname'] ?><br>
            MIDDLE NAME:   <?= $_SESSION['mname'] ?><br>
            LAST NAME:      <?= $_SESSION['lname'] ?><br>
            GENDER:    <?= $_SESSION['gender'] ?><br>
    </h3>
    </div>
    <div class="col-md-3"> </div>
</div>


<?php include('includes/footer.php'); ?>