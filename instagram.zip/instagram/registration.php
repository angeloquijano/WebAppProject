<?php include('includes/header.php'); ?>
<?php include('includes/navbar2.php'); ?>

<br><br>
<?php
    include('includes/dbcon.php');
    session_start();

    if(isset($_POST['submit'])){
        $fname = $_POST['fname'];
        $lname = $_POST['lname'];
        $mname = $_POST['mname'];
        $uname = $_POST['uname'];
        $email = $_POST['email']; 
        $gender = $_POST['gender']; 
        $pass = $_POST['pass'];
        $cpass = $_POST['cpass'];

        $err = 0;

        if(empty($fname)){
            $err =  1;
            $fnameErr = "First Name is required";
        }
        elseif(!preg_match("/^[a-zA-Z -]+$/", $fname)) {
            $err =  1;
            $fnameErr = "First Name must be letters only";
        }
        if(empty($mname)){
            $err =  1;
            $mnameErr = "Middle Name is required";
        }
        elseif(!preg_match("/^[a-zA-Z -]+$/", $mname)) {
            $err =  1;
            $mnameErr = "Middle Name must be letters only";
        }
        if(empty($lname)){
            $err =  1;
            $lnameErr = "Last Name is required";
        }
        elseif(!preg_match("/^[a-zA-Z -]+$/", $lname)) {
            $err =  1;
            $lnameErr = "Last Name must be letters only";
        }
        if(empty($uname)){
            $err =  1;
            $unameErr = "Username is required";
        }
        elseif(strlen($uname) < 5){
            $err =  1;
            $unameErr = "Username must be minimum of 5 letters";
        }
        if(empty($email)){
            $err =  1;
            $emailErr = "Email is required";
        }
        elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
          $emailErr = "Invalid email format"; 
        }
        if(empty($pass)){
            $err =  1;
            $passErr = "Password is required";
        }
        elseif(strlen($pass) < 6){
            $err =  1;
            $passErr = "Password must be minimum of 6 letters";
        }
        if(empty($cpass)){
            $err =  1;
            $cpassErr = "Confirm Password is required";
        }
        elseif($cpass != $pass){
            $err =  1;
            $cpassErr = "Confirm Password not match";
        }

        if($err == 0){
            $SQL = $mysqli->query("INSERT INTO users(fname,lname,mname,username,gender,password,email) VALUES('$fname', '$lname', '$mname', '$uname', '$gender', '$pass', '$email')");

            if($SQL == "")
            {
                $_SESSION['errorMSG'] = $mysqli->error;
                // header("Location: registration.php");
            }
            else
            {
                $_SESSION['successMSG'] = "Successfully registered !";
                header("Location: index.php");
            }
            

        }

    }



?>





<div class="row">
    <div class="col-md-4"> </div>
    <div class="col-md-4"> 
    
    <form method="POST" action="<?= $_SERVER['PHP_SELF'] ?>">
        <h1> REGISTRATION  FORM </h1>

        <?php
            if(isset($_SESSION['errorMSG'])){
                echo "<div class='alert alert-danger dismissable'>".$_SESSION['errorMSG']."</div>";
                unset($_SESSION['errorMSG']);
            }
        ?>

        <div class="form-group">
            <label>First Name</label>
            <input type="text" name="fname" value="<?php if(isset($fname)){echo $fname;} ?>" class="form-control" placeholder="First Name">
            <?php
                if(isset($fnameErr)){
                    echo "<div class='alert alert-danger'>$fnameErr</div>";
                }
            ?>
        </div>

        <div class="form-group">
            <label>Middle Name</label>
            <input type="text" name="mname" value="<?php if(isset($mname)){echo $mname;} ?>" class="form-control" placeholder="Middle Name">
            <?php
                if(isset($mnameErr)){
                    echo "<div class='alert alert-danger'>$mnameErr</div>";
                }
            ?>
        </div>

        <div class="form-group">
            <label>Last Name</label>
            <input type="text" name="lname" value="<?php if(isset($lname)){echo $lname;} ?>" class="form-control" placeholder="Last Name">
            <?php
                if(isset($lnameErr)){
                    echo "<div class='alert alert-danger'>$lnameErr</div>";
                }
            ?>
        </div>

        <div class="form-group">
            <label>Username</label>
            <input type="text" name="uname" value="<?php if(isset($uname)){echo $uname;} ?>" class="form-control" placeholder="Username">
            <?php
                if(isset($unameErr)){
                    echo "<div class='alert alert-danger'>$unameErr</div>";
                }
            ?>
        </div>

        <div class="form-group">
            <label>Email address</label>
            <input type="text" name="email" value="<?php if(isset($email)){echo $email;} ?>" class="form-control" placeholder="Email">
            <?php
                if(isset($emailErr)){
                    echo "<div class='alert alert-danger'>$emailErr</div>";
                }
            ?>
        </div>

        <div class="form-group">
            <label>Gender</label>
            <select name="gender" class="form-control">
                <option value="M">Male</option>
                <option value="F">Female</option>
            <select>
        </div>

        <div class="form-group">
            <label>Password</label>
            <input type="password" name="pass" class="form-control" placeholder="Password">
            <?php
                if(isset($passErr)){
                    echo "<div class='alert alert-danger'>$passErr</div>";
                }
            ?>
        </div>

        <div class="form-group">
            <label>Confirm Password</label>
            <input type="password" name="cpass" class="form-control" placeholder="Confirm Password">
            <?php
                if(isset($cpassErr)){
                    echo "<div class='alert alert-danger'>$cpassErr</div>";
                }
            ?>
        </div>

        <input type="submit" name="submit" class="btn btn-success" value="REGISTER" id="submitRegistration">
    </form>
    
    </div>
    <div class="col-md-4"> </div>
</div>

<?php include('includes/footer.php'); ?>
