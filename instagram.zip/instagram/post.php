<?php
	session_start();

	include('includes/dbcon.php');
	
	$target_dir = "images/";
	$target_file = $target_dir . basename($_FILES['image']["name"]);

	if (move_uploaded_file($_FILES['image']["tmp_name"], $target_file)) {

		$id = $_SESSION['id'];
		$caption = $_POST['caption'];

        $mysqli->query("INSERT INTO posts(user_id,caption,img) VALUES('$id', '$caption', '$target_file')");
        $_SESSION['successMSG'] = "Successfully Posted !";
    } else {
        $_SESSION['errorMSG'] = "There was a problem uploading your image. Please try again !";
    }
	
	header("Location: home.php");
?>