<?php include('includes/mainHeader.php'); ?>

<!--main-->
<div class="container" id="main">
   <div class="row">

      <div class="col-sm-6 col-md-3 col-2">

      </div>

      <div class="col-sm-6 col-md-5 col-md-offset-1 col-1">
      </div>

      <div class="col-sm-6 col-md-3 col-3">
      </div>
  </div>
  
  	<hr>
    
    <br>
    
    <div class="clearfix"></div>
  </div>
</div><!--/main-->

<?php
  include('includes/mainFooter.php');
  include('includes/dbcon.php');

  $id = $_GET['user_id'];

  $sql = "SELECT CONCAT(fname, ' ', lname) as name, user_id as id, avatar, gender, email, created_at, privacy FROM users where user_id = '$id'";
  $user = $mysqli->query($sql)->fetch_assoc();
  $name = $user['name'];

  // if($_SESSION['id'] == $id || $user['privacy'] == 'public')
  
  if($_SESSION['id'] == $id || $user['privacy'] == 'public')
  {
    $sql = "SELECT * FROM posts where user_id = '$id'";
    $result = $mysqli->query($sql);

    if ($result->num_rows > 0) {
      while($post = $result->fetch_assoc()) {
        ?>
          <script type="text/javascript">
            $('.col-1').append(`
              <div class="panel panel-default">
                <div class="panel-heading">
                  <!-- POST OPTIONS -->
                  <a href="#" class="dropdown-toggle pull-right" data-toggle="dropdown">
                    <small><i class="fa fa-ellipsis-h"></i></small>
                  </a>
                  <ul class="nav dropdown-menu pull-right" style="position: absolute; top: 35px; right: 30px">
                    <li><a href="#"><i class="fa fa-pencil"></i> Edit</a></li>
                    <li><a href="#"><i class="fa fa-cross"></i> Delete</a></li>
                  </ul>
                   
                   <a href="timeline.php?user_id=<?php echo $user['id']; ?>" class="timeline-link" target="_blank">
                   <h4>
                     <img src="<?php echo $user['avatar'] ?>" alt="user_avatar" width="25px" height="25px">
                     <?php echo $name; ?>
                   </h4>
                   </a>

                 </div>
                <div class="panel-thumbnail"><img src="<?php echo $post['img'] ?>" class="img-responsive"></div>
                <div class="panel-body">
                 <h4></h4>
                  <p class="lead"><?php echo $post['caption'] ?></p>
                  <p>6 Likes, 9 Comments</p>
                  
                  <p>
                    <img src="assets/img/uFp_tsTJboUY7kue5XAsGAs28.png" height="28px" width="28px">
                    <img src="assets/img/photo_002.jpg" height="28px" width="28px">
                  </p>
                </div>
              </div>`);
          </script>
        <?php
      }
    }
    else
    {
      ?>
        <script>
          $('.col-1').append(`<div class='alert alert-info dismissable'>This account has no posts.</div>`);
          $('hr').remove();
        </script>
      <?php
    }
  }
  else
  {
    ?>
      <script>
        $('.col-1').append(`<div class='alert alert-danger dismissable'>This account is private.</div>`);
        $('hr').remove();
      </script>
    <?php
  }
?>

<script>
  $(".col-2").append(`
    <div class="panel panel-default" style="position: fixed; width: 20%;">
      <div class="panel-heading">
        <!-- PROFILE INFO -->
         <h4>
           <?php echo $name; ?>'s Profile
         </h4>
         <img src="<?php echo $user['avatar'] ?>" width="100%" style="max-height: 200px;"/>

       </div>
      <div class="panel-body">
        <p class="lead">Details</p>
        <h5>
          <b>Email: </b>
          <?php echo $user['email'] ?>
        </h5>
        <h5>
          <b>Gender: </b>
          <?php echo $user['gender'] == "F" ? $user['gender'] . 'em' : $user['gender'] ?>ale
        </h5>
        <h5>
          <b>Joined on: </b>
          <?php echo date_format(date_create(explode(' ', $user['created_at'])[0]), 'F j, Y') ?>
        </h5>
      </div>
    </div>`);
</script>

</body></html>