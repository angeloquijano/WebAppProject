<?php 
    session_start();

    if(isset($_SESSION['id']))
    {
      header("Location: home.php");
    }

    include('includes/header.php'); 
    include('includes/dbcon.php');
    if(isset($_POST['login'])){
        
        $username = $_POST['username'];
        $pass = $_POST['pass'];

        $res = $mysqli->query("SELECT * FROM users WHERE username = '$username' AND password = '$pass'");

        if($res->num_rows == 0){
            $_SESSION['errorMSG'] = "Invalid Username / Password";
        }
        else{
            $row = $res->fetch_array();

            $_SESSION['id'] = $row['user_id'];
            $_SESSION['username'] = $row['username'];
            $_SESSION['email'] = $row['email'];
            $_SESSION['fname'] = $row['fname'];
            $_SESSION['lname'] = $row['lname'];
            $_SESSION['mname'] = $row['mname'];
            $_SESSION['gender'] = $row['gender'];

            header("Location: home.php");
        }
    }
?>


<div class="row">
    <div class="col-md-4"> </div>
    <div class="col-md-4"> 
    
    <form method="POST" action="index.php">
        <h1> LOG IN FORM  </h1>
        <?php
            if(isset($_SESSION['errorMSG'])){
                echo "<div class='alert alert-danger dismissable'>".$_SESSION['errorMSG']."</div>";
                unset($_SESSION['errorMSG']);
            }
            elseif(isset($_SESSION['successMSG'])){
                echo "<div class='alert alert-success dismissable'>".$_SESSION['successMSG']."</div>";
                unset($_SESSION['successMSG']);
            }
        ?>
        <div class="form-group">
            <label>Username</label>
            <input type="text" name="username" class="form-control" placeholder="Username">
        </div>
        <div class="form-group">
            <label>Password</label>
            <input type="password" name="pass" class="form-control" placeholder="Password">
        </div>

        <button type="submit" name="login" class="btn btn-info">Submit</button>
        <a href="registration.php" class="btn btn-success">Register </a>
    </form>
    
    </div>
    <div class="col-md-4"> </div>
</div>

<?php include('includes/footer.php'); ?>