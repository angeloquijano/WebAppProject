<?php
    include('includes/dbcon.php');

    $privacy = $_POST['privacy'];
    $id = $_POST['id'];

    echo $mysqli->query("UPDATE users SET privacy='$privacy' WHERE user_id='$id'");
?>